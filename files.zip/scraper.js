'use strict';
require('dotenv').config();
const { chromium } = require('playwright');
const https = require('https');
const http  = require('http');
const db    = require('./db');
const {
  sleep, randomDelay, generateId, normalizePrezzo,
  detectTipo, detectRischio, regioneFromProvincia,
  buildSummary, buildRischi, buildPassi
} = require('./utils');

const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || '';
const MAX_PAGINE    = parseInt(process.env.MAX_PAGINE || '300');
const DELAY_MIN     = parseInt(process.env.DELAY_MIN_MS || '2000');
const DELAY_MAX     = parseInt(process.env.DELAY_MAX_MS || '4000');

// ─── Download PDF ─────────────────────────────────────────────────────────────
function downloadPDF(url, cookieStr) {
  return new Promise((resolve, reject) => {
    if (!url) return reject(new Error('URL vuoto'));
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/pdf,*/*',
        'Referer': 'https://www.astalegale.net/',
        ...(cookieStr ? { 'Cookie': cookieStr } : {}),
      },
      timeout: 40000,
    }, res => {
      if ([301,302,303].includes(res.statusCode) && res.headers.location)
        return downloadPDF(res.headers.location, cookieStr).then(resolve).catch(reject);
      if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        if (buf.length < 500) return reject(new Error('File troppo piccolo'));
        resolve(buf);
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

// ─── Chiama Claude ─────────────────────────────────────────────────────────────
function callClaude(messages, maxTokens) {
  return new Promise((resolve, reject) => {
    if (!ANTHROPIC_KEY) return reject(new Error('ANTHROPIC_API_KEY mancante'));
    const body = JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: maxTokens || 800,
      messages,
    });
    const req = https.request({
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Length': Buffer.byteLength(body),
      },
      timeout: 60000,
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const p = JSON.parse(data);
          if (p.error) return reject(new Error(p.error.message));
          resolve(p);
        } catch(e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout Claude')); });
    req.write(body);
    req.end();
  });
}

// ─── Analisi AI con PDF ────────────────────────────────────────────────────────
async function analizzaConPDF(pdfBuffer, testoScheda, infoAsta) {
  const base64 = pdfBuffer.toString('base64');
  const content = [
    { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: base64 } },
    { type: 'text', text: costruisciPrompt(testoScheda, infoAsta, true) },
  ];
  const result = await callClaude([{ role: 'user', content }], 1200);
  return estraiJSON(result.content?.[0]?.text || '');
}

// ─── Analisi AI con solo testo della pagina (NO PDF) ───────────────────────────
async function analizzaConTesto(testoScheda, infoAsta) {
  const content = [{ type: 'text', text: costruisciPrompt(testoScheda, infoAsta, false) }];
  const result = await callClaude([{ role: 'user', content }], 800);
  return estraiJSON(result.content?.[0]?.text || '');
}

// ─── Prompt unificato ──────────────────────────────────────────────────────────
function costruisciPrompt(testoScheda, infoAsta, haPDF) {
  return `Sei un esperto legale di aste immobiliari italiane. Analizza ${haPDF ? 'il documento PDF allegato e ' : ''}le informazioni di questa asta e rispondi SOLO con JSON valido, senza testo prima o dopo.

${haPDF ? 'Il PDF contiene la perizia/avviso di vendita ufficiale.' : ''}

INFORMAZIONI ASTA:
${infoAsta}

TESTO COMPLETO DELLA SCHEDA:
${testoScheda.slice(0, 3000)}

Rispondi SOLO con questo JSON (tutti i campi obbligatori):
{
  "proprieta": {
    "stato": "ok|warn|bad|unk",
    "label": "es: Piena proprietà al 100%",
    "dettaglio": "spiegazione in 1-2 righe senza gergo legale"
  },
  "occupazione": {
    "stato": "ok|warn|bad|unk",
    "label": "es: Libero / Inquilino fino a gen-2028 / Proprietario occupante",
    "dettaglio": "chi c'è, fino a quando, cosa significa per chi compra"
  },
  "abusi": {
    "stato": "ok|warn|bad|unk",
    "label": "es: Nessun abuso / Difformità sanabile / Abuso grave",
    "dettaglio": "descrizione precisa. Se sanabile: costo stimato. Se grave: rischio demolizione?"
  },
  "sanatoria": {
    "stato": "ok|warn|bad|unk",
    "label": "es: Nessuna / Pendente / Già ottenuta",
    "dettaglio": "stato delle pratiche. Il nuovo proprietario eredita problemi?"
  },
  "affitto": {
    "presente": false,
    "canone": null,
    "scadenza": null,
    "tipo": null
  },
  "rischio_globale": "low|med|high",
  "alert_principale": "La cosa PIÙ IMPORTANTE in 1 frase semplice per chi non è del settore"
}

Regole: ok=nessun problema, warn=attenzione, bad=grave, unk=non determinabile.
Se non hai abbastanza informazioni su un campo, usa "unk" non inventare.`;
}

function estraiJSON(text) {
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error('Nessun JSON nella risposta');
  return JSON.parse(m[0]);
}

// ─── Salva analisi nel DB ──────────────────────────────────────────────────────
function salvaAnalisi(codice, a) {
  db.updatePerizia(codice, {
    proprieta_stato:       a.proprieta?.stato     || 'unk',
    proprieta_label:       a.proprieta?.label     || 'Da verificare',
    proprieta_dettaglio:   a.proprieta?.dettaglio || '',
    occupazione_stato:     a.occupazione?.stato     || 'unk',
    occupazione_label:     a.occupazione?.label     || 'Da verificare',
    occupazione_dettaglio: a.occupazione?.dettaglio || '',
    abusi_stato:           a.abusi?.stato     || 'unk',
    abusi_label:           a.abusi?.label     || 'Da verificare',
    abusi_dettaglio:       a.abusi?.dettaglio || '',
    sanatoria_stato:       a.sanatoria?.stato     || 'unk',
    sanatoria_label:       a.sanatoria?.label     || 'Da verificare',
    sanatoria_dettaglio:   a.sanatoria?.dettaglio || '',
    affitto_canone:        a.affitto?.canone   || null,
    affitto_scadenza:      a.affitto?.scadenza || null,
    affitto_tipo:          a.affitto?.tipo     || null,
    rischio:               ['low','med','high'].includes(a.rischio_globale) ? a.rischio_globale : 'med',
  });
}

// ─── Analizza tutte le aste pendenti ─────────────────────────────────────────
async function analizzaTutteLePerizie() {
  if (!ANTHROPIC_KEY) {
    console.log('[AI] Nessuna API key — salto analisi');
    return;
  }
  console.log('[AI] Avvio analisi automatica di tutte le aste...');
  let ok = 0, ko = 0;

  // Aste con PDF scaricabile — analisi PDF + testo
  const conPDF = db.getAste_senzaPerizia(50);
  console.log('[AI] ' + conPDF.length + ' aste con PDF');
  for (const asta of conPDF) {
    try {
      console.log('[AI] PDF: ' + asta.codice);
      const buf = await downloadPDF(asta.url_perizia, null);
      const analisi = await analizzaConPDF(buf, asta.testo_scheda || '', buildInfo(asta));
      salvaAnalisi(asta.codice, analisi);
      ok++;
      console.log('[AI] ✓ ' + asta.codice + ' | ' + analisi.rischio_globale + ' | ' + (analisi.alert_principale||'').slice(0,60));
      await sleep(1200);
    } catch(e) {
      console.error('[AI] PDF fallito ' + asta.codice + ': ' + e.message + ' — provo con testo');
      // Fallback: analisi col solo testo della scheda
      try {
        const analisi = await analizzaConTesto(asta.testo_scheda || buildInfoFallback(asta), buildInfo(asta));
        salvaAnalisi(asta.codice, analisi);
        ok++;
        await sleep(800);
      } catch(e2) {
        console.error('[AI] Testo fallito ' + asta.codice + ': ' + e2.message);
        ko++;
      }
    }
  }

  // Aste senza PDF — analisi con testo scheda (già salvato durante scraping)
  const senza = db.getAste_senzaPerizia_noPDF(200);
  console.log('[AI] ' + senza.length + ' aste senza PDF — analisi da testo scheda');
  for (const asta of senza) {
    try {
      const analisi = await analizzaConTesto(asta.testo_scheda || buildInfoFallback(asta), buildInfo(asta));
      salvaAnalisi(asta.codice, analisi);
      ok++;
      await sleep(600);
    } catch(e) {
      ko++;
      console.error('[AI] Errore ' + asta.codice + ': ' + e.message);
    }
  }

  console.log('[AI] Fine — ' + ok + ' analizzate, ' + ko + ' errori');
}

function buildInfo(a) {
  return [
    'Codice: ' + a.codice,
    'Titolo: ' + (a.titolo||''),
    'Prezzo base: €' + (a.prezzo||0),
    'Valore stimato: €' + (a.mercato||0),
    'Tribunale: ' + (a.tribunale||''),
    'N. asta: ' + (a.asta_n||1),
    'Stato dichiarato: ' + (a.stato||''),
    'Data asta: ' + (a.data_asta||''),
    'Composizione: ' + (a.composizione||''),
    'Categoria catastale: ' + (a.catastale||''),
  ].filter(x => !x.endsWith(': ')).join('\n');
}

function buildInfoFallback(a) {
  return buildInfo(a) + '\n\n[Nessun testo aggiuntivo disponibile — usa i dati sopra per l\'analisi]';
}

// ─── SCRAPING SINGOLA SCHEDA (salva anche tutto il testo) ─────────────────────
async function scrapeDettaglio(page, link, cookieStr) {
  await page.goto(link, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await sleep(700);

  const parts = link.split('/');
  const last  = parts[parts.length - 1] || '';
  const m     = last.match(/([A-Z]{1,3}\d{5,})/i);
  const codice = m ? m[1].toUpperCase() : last.split('-')[0].slice(0, 20);
  if (!codice || codice.length < 4) return null;

  const get = async (...sels) => {
    for (const s of sels) {
      try { const el = await page.$(s); if (el) { const t = (await el.textContent()).trim(); if (t) return t; } }
      catch(_) {}
    }
    return null;
  };

  const titolo = await get('h1','h2.titolo','[class*="titolo"]','.detail-title','.page-title')
    || last.replace(/-/g,' ').replace(/[A-Z]\d+/g,'').trim().slice(0,120)
    || 'Asta ' + codice;

  const prezzoRaw = await get(
    '.prezzo-base strong','.prezzo strong','[class*="prezzo"] strong','[class*="prezzo"]',
    '.base-price','td:has-text("Prezzo base") + td','td:has-text("Prezzo") + td','.importo'
  );
  const prezzo = normalizePrezzo(prezzoRaw);
  if (!prezzo) return null;

  // Salva TUTTO il testo visibile della scheda — verrà mandato a Claude
  let testoScheda = '';
  try {
    testoScheda = await page.$eval('body', el => {
      // Rimuovi script e style
      const clone = el.cloneNode(true);
      clone.querySelectorAll('script,style,nav,header,footer,.cookie,.banner').forEach(n => n.remove());
      return clone.innerText.replace(/\s+/g, ' ').trim();
    });
  } catch(_) {}

  const [
    tribunale, dataAsta, mqRaw, stato, catEl, indirizzoEl,
    scadRaw, rialzoRaw, mercatoRaw, caparraRaw, astaNumRaw, composizione
  ] = await Promise.all([
    get('td:has-text("Tribunale") + td','.tribunale','[class*="tribunale"]'),
    get('td:has-text("Data") + td','.data-asta','[class*="data-vendita"]'),
    get('td:has-text("Superficie") + td','.superficie','[class*="mq"]'),
    get('td:has-text("Occupazione") + td','.occupazione','[class*="occup"]','td:has-text("Stato") + td'),
    get('td:has-text("Categoria catastale") + td','td:has-text("Categoria") + td'),
    get('.indirizzo','td:has-text("Indirizzo") + td','.localita','td:has-text("Comune") + td'),
    get('td:has-text("Scadenza") + td','.scadenza'),
    get('td:has-text("Rialzo") + td','.rialzo-minimo'),
    get('td:has-text("Valore stimato") + td','td:has-text("Valore di mercato") + td'),
    get('td:has-text("Cauzione") + td','.cauzione','td:has-text("Caparra") + td'),
    get('.numero-asta','td:has-text("Esperimento") + td','td:has-text("N. vendita") + td'),
    get('td:has-text("Composizione") + td','.composizione'),
  ]);

  // Trova URL documenti
  let urlPerizia = null, urlAvviso = null;
  try {
    const docs = await page.$$eval('a[href]', els =>
      els.map(e => ({ href: e.href, txt: (e.textContent||'').toLowerCase().trim() }))
         .filter(l => l.href && (l.href.includes('/file/') || l.href.includes('documents.') || l.href.includes('.pdf') || l.txt.includes('perizia') || l.txt.includes('avviso') || l.txt.includes('ordinanza')))
    );
    for (const d of docs) {
      if (!urlPerizia && (d.txt.includes('perizia') || d.txt.includes('relazione') || d.txt.includes('stima') || d.href.includes('/file/')))
        urlPerizia = d.href;
      if (!urlAvviso && (d.txt.includes('avviso') || d.txt.includes('vendita') || d.txt.includes('ordinanza')))
        urlAvviso = d.href;
    }
  } catch(_) {}

  // Parsing indirizzo
  let citta = '', provincia = '', regione = '';
  if (indirizzoEl) {
    const mp = indirizzoEl.match(/\(([A-Z]{2})\)/);
    if (mp) provincia = mp[1];
    const p2 = indirizzoEl.split(',');
    citta = p2.length >= 2
      ? p2[p2.length-2].trim().replace(/\([A-Z]{2}\)/g,'').trim()
      : indirizzoEl.replace(/\([A-Z]{2}\)/g,'').trim().slice(0,50);
    regione = regioneFromProvincia(provincia);
  }

  const mercato = normalizePrezzo(mercatoRaw) || Math.round(prezzo * 1.55);
  const caparra = normalizePrezzo(caparraRaw) || Math.round(prezzo * 0.1);
  const astaN   = parseInt(astaNumRaw) || 1;
  const tipo    = detectTipo(catEl || titolo);
  const rischio = detectRischio({ astaN, stato: stato||'', titolo });
  const mq      = mqRaw ? parseFloat(mqRaw.replace(/[^\d,.]/g,'').replace(',','.')) : null;

  return {
    id: generateId(codice), codice,
    titolo: titolo.slice(0,250),
    indirizzo: indirizzoEl, citta, provincia, regione, tipo,
    prezzo, mercato, mq, caparra, rischio,
    stato: stato || 'Da verificare',
    asta_n: astaN, data_asta: dataAsta, scadenza: scadRaw, rialzo: rialzoRaw,
    composizione, catastale: catEl, procedura: 'Vendita telematica', tribunale,
    summary: buildSummary({ titolo, citta, prezzo, mercato, astaN, stato: stato||'' }),
    rischi_json:   JSON.stringify(buildRischi({ astaN, stato: stato||'', prezzo, mercato })),
    passi_json:    JSON.stringify(buildPassi({ tribunale, caparra, scadenza: scadRaw })),
    url: link, url_perizia: urlPerizia, url_avviso: urlAvviso,
    testo_scheda:  testoScheda.slice(0, 6000), // testo completo per analisi AI
  };
}

// ─── SCRAPING PRINCIPALE ──────────────────────────────────────────────────────
async function runScraper() {
  const t0 = Date.now();
  console.log('[' + new Date().toISOString() + '] === AVVIO SCRAPING + ANALISI ITALIA ===');
  let totale = 0, nuove = 0, aggiornate = 0, errori = 0;

  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--disable-gpu'],
  });

  try {
    const ctx = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      viewport: { width: 1280, height: 900 },
      locale: 'it-IT',
      timezoneId: 'Europe/Rome',
      extraHTTPHeaders: { 'Accept-Language': 'it-IT,it;q=0.9' },
    });
    await ctx.route('**/*.{png,jpg,jpeg,gif,webp,woff,woff2,ttf,otf,eot,svg}', r => r.abort());
    await ctx.route('**/analytics**', r => r.abort());
    await ctx.route('**/googletagmanager**', r => r.abort());

    const page = await ctx.newPage();
    let vuote = 0;

    for (let p = 1; p <= MAX_PAGINE; p++) {
      const url = p === 1
        ? 'https://www.astalegale.net/Immobili'
        : 'https://www.astalegale.net/Immobili?pagina=' + p;

      console.log('[p.' + p + '] Scraping...');
      try {
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 40000 });
        await sleep(2500);
        await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
        await sleep(800);
      } catch(e) {
        errori++;
        if (p === 1) break;
        continue;
      }

      const title = await page.title().catch(() => '');
      if (title.includes('404') || title.includes('Errore')) { console.log('Fine a p.' + p); break; }

      let links = [];
      try {
        links = await page.$$eval('a[href]', els =>
          [...new Set(els.map(e => e.href).filter(h => h && h.includes('/Aste/Detail/') && h.length > 50))]
        );
      } catch(_) {}

      if (!links.length) {
        vuote++;
        if (vuote >= 3) { console.log('3 pagine vuote — fine'); break; }
        continue;
      }
      vuote = 0;
      console.log('  ' + links.length + ' aste trovate');

      const cookies = await ctx.cookies();
      const cookieStr = cookies.map(c => c.name + '=' + c.value).join('; ');

      for (const link of links) {
        try {
          const asta = await scrapeDettaglio(page, link, cookieStr);
          if (!asta) continue;
          const existing = db.getAsta(asta.codice);
          db.upsertAsta(asta);
          if (!existing) {
            nuove++;
            console.log('  + ' + asta.codice + ' ' + (asta.citta||'').slice(0,12) + ' €' + asta.prezzo + (asta.url_perizia?' 📄':'') + (asta.testo_scheda?.length > 200?' 📝':''));
          } else {
            aggiornate++;
          }
          totale++;
          await sleep(randomDelay(DELAY_MIN, DELAY_MAX));
        } catch(e) {
          errori++;
          console.error('  ERR: ' + e.message.slice(0,60));
          await sleep(800);
        }
      }
      await sleep(randomDelay(2000, 4000));
    }
    await ctx.close();
  } finally {
    await browser.close();
  }

  const durata = Date.now() - t0;
  db.logScraping({ totale, nuove, aggiornate, errori, durata_ms: durata });
  console.log('Scraping fine: ' + nuove + ' nuove in ' + Math.round(durata/60000) + 'min. DB: ' + (db.getStats()?.totale||0) + ' aste');

  // ANALISI AUTOMATICA IMMEDIATA dopo scraping
  console.log('[AI] Avvio analisi automatica di tutte le aste nuove...');
  analizzaTutteLePerizie().catch(e => console.error('[AI]', e.message));
}

if (require.main === module) {
  runScraper().catch(e => { console.error(e); process.exit(1); });
}
module.exports = { runScraper, analizzaTutteLePerizie };
